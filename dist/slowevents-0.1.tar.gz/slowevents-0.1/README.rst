Matty: Middleman app for transactions
#########################################

Matty is a middleman app to handle providers of different services and clients.




